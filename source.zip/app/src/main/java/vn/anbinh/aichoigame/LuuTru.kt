package vn.anbinh.aichoigame

import android.content.Context
import org.json.JSONArray
import java.io.File

/** Cài đặt của người dùng. */
data class CaiDat(
    val apiKey: String,
    val model: String,
    val cheDo: String,      // nhiem_vu | danh_quai | ca_hai
    val soBuoc: Int,
    val choGiay: Double,
    val ghiChu: String
) {
    fun luu(c: Context) {
        c.getSharedPreferences(TEN, Context.MODE_PRIVATE).edit()
            .putString("api_key", apiKey.trim())
            .putString("model", model.trim().ifEmpty { MODEL_MAC_DINH })
            .putString("che_do", cheDo)
            .putInt("so_buoc", soBuoc)
            .putFloat("cho_giay", choGiay.toFloat())
            .putString("ghi_chu", ghiChu)
            .apply()
    }

    companion object {
        private const val TEN = "cai_dat"
        const val MODEL_MAC_DINH = "claude-sonnet-5-5"

        fun doc(c: Context): CaiDat {
            val sp = c.getSharedPreferences(TEN, Context.MODE_PRIVATE)
            return CaiDat(
                apiKey = sp.getString("api_key", "") ?: "",
                model = sp.getString("model", MODEL_MAC_DINH) ?: MODEL_MAC_DINH,
                cheDo = sp.getString("che_do", "ca_hai") ?: "ca_hai",
                soBuoc = sp.getInt("so_buoc", 500),
                choGiay = sp.getFloat("cho_giay", 1.2f).toString().toDouble(),
                ghiChu = sp.getString("ghi_chu", "") ?: ""
            )
        }
    }
}

/** Sổ tay: những điều AI tự ghi nhớ lâu dài về game. */
class SoTay(private val c: Context) {
    private val sp = c.getSharedPreferences("so_tay", Context.MODE_PRIVATE)

    fun ds(): List<String> {
        val a = runCatching { JSONArray(sp.getString("ds", "[]")) }.getOrDefault(JSONArray())
        return (0 until a.length()).map { a.getString(it) }
    }

    fun them(s: String) {
        val hien = ds().toMutableList()
        if (s in hien) return
        hien.add(s)
        val moi = JSONArray()
        hien.takeLast(40).forEach { moi.put(it) }
        sp.edit().putString("ds", moi.toString()).apply()
    }

    fun xoa() = sp.edit().clear().apply()
}

/** Nhật ký chạy, lưu trong bộ nhớ riêng của app. */
object NhatKy {
    private fun file(c: Context) = File(c.filesDir, "nhat_ky.txt")

    @Synchronized
    fun ghi(c: Context, dong: String) {
        val f = file(c)
        if (f.exists() && f.length() > 300_000) {
            val giu = f.readLines().takeLast(400)
            f.writeText(giu.joinToString("\n") + "\n")
        }
        val gio = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        f.appendText("$gio $dong\n")
    }

    fun doc(c: Context, soDong: Int = 60): String {
        val f = file(c)
        if (!f.exists()) return "(chưa có nhật ký)"
        return f.readLines().takeLast(soDong).reversed().joinToString("\n")
    }

    fun xoa(c: Context) {
        file(c).delete()
    }
}
