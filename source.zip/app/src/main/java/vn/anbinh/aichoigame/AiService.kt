package vn.anbinh.aichoigame

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Dịch vụ Trợ năng: hiện nút nổi "AI", chụp màn hình, hỏi Claude và tự chạm/vuốt.
 */
class AiService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AiService? = null
        private const val CANH_DAI_ANH = 1024   // cạnh dài ảnh gửi AI (tiết kiệm phí)
        private const val SO_BUOC_NHO = 12
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var nut: TextView? = null

    @Volatile
    private var dangChay = false
    private var luong: Thread? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        themNutNoi()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        dangChay = false
        nut?.let { v -> runCatching { wm?.removeView(v) } }
        nut = null
        instance = null
        super.onDestroy()
    }

    // ------------------------------------------------------------ nút nổi
    @SuppressLint("ClickableViewAccessibility")
    private fun themNutNoi() {
        val tv = TextView(this).apply {
            text = "▶ AI"
            setTextColor(Color.WHITE)
            textSize = 13f
            maxWidth = (resources.displayMetrics.widthPixels * 0.45).toInt()
            setPadding(26, 16, 26, 16)
            background = GradientDrawable().apply {
                cornerRadius = 36f
                setColor(0xCC1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 220
        }

        var dauX = 0f
        var dauY = 0f
        var gocX = 0
        var gocY = 0
        var keo = false
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dauX = e.rawX; dauY = e.rawY; gocX = lp.x; gocY = lp.y; keo = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - dauX
                    val dy = e.rawY - dauY
                    if (abs(dx) > 15 || abs(dy) > 15) keo = true
                    if (keo) {
                        lp.x = gocX + dx.toInt()
                        lp.y = gocY + dy.toInt()
                        runCatching { wm?.updateViewLayout(v, lp) }
                    }
                }
                MotionEvent.ACTION_UP -> if (!keo) batTat()
            }
            true
        }
        runCatching { wm?.addView(tv, lp) }.onSuccess { nut = tv }
    }

    private fun hienTrangThai(s: String) {
        main.post {
            val dau = if (dangChay) "■ " else "▶ AI  "
            nut?.text = dau + s.take(60)
            (nut?.background as? GradientDrawable)?.setColor(
                if (dangChay) 0xCCC62828.toInt() else 0xCC1565C0.toInt()
            )
        }
    }

    private fun batTat() {
        if (dangChay) {
            dangChay = false
            hienTrangThai("đang dừng...")
            return
        }
        if (luong?.isAlive == true) {
            hienTrangThai("đang dừng lượt trước, chờ chút")
            return
        }
        val cd = CaiDat.doc(this)
        if (cd.apiKey.isBlank()) {
            hienTrangThai("Chưa có API key, mở app để nhập")
            return
        }
        dangChay = true
        hienTrangThai("bắt đầu")
        luong = thread(name = "ai-choi-game") { vongLap(cd) }
    }

    // ------------------------------------------------------------ vòng lặp chính
    private fun vongLap(cd: CaiDat) {
        val claude = ClaudeClient(cd.apiKey, cd.model)
        val soTay = SoTay(this)
        val lichSu = ArrayList<String>()
        val heThong = Prompts.heThong(cd.cheDo, cd.ghiChu)
        NhatKy.ghi(this, "=== Bắt đầu: chế độ ${cd.cheDo}, model ${cd.model}, tối đa ${cd.soBuoc} bước")

        try {
            for (buoc in 1..cd.soBuoc) {
                if (!dangChay) break
                val goc = chupManHinh()
                if (goc == null) {
                    hienTrangThai("Không chụp được màn hình, thử lại")
                    Thread.sleep(2000)
                    continue
                }
                val rong = goc.width
                val cao = goc.height
                val tiLe = min(1.0, CANH_DAI_ANH.toDouble() / max(rong, cao))
                val nho = if (tiLe < 1.0)
                    Bitmap.createScaledBitmap(goc, (rong * tiLe).toInt(), (cao * tiLe).toInt(), true)
                else goc
                val bos = ByteArrayOutputStream()
                nho.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                val rongNho = nho.width
                val caoNho = nho.height
                if (nho !== goc) nho.recycle()
                goc.recycle()

                hienTrangThai("B$buoc: đang suy nghĩ...")
                val kq = claude.hoi(
                    heThong,
                    Prompts.luot(soTay.ds(), lichSu.takeLast(SO_BUOC_NHO), buoc, rongNho, caoNho),
                    b64
                )
                if (!dangChay) break

                val ds = kq.optJSONArray("thao_tac") ?: JSONArray()
                val moTa = ArrayList<String>()
                for (i in 0 until min(ds.length(), 5)) {
                    if (!dangChay) break
                    val tt = ds.optJSONObject(i) ?: continue
                    moTa.add(runCatching { thucHien(tt, tiLe, rong, cao) }
                        .getOrElse { "lỗi thao tác: ${it.message}" })
                    Thread.sleep(250)
                }

                val suyNghi = kq.optString("suy_nghi")
                val dong = "[$buoc] ${kq.optString("tinh_trang")} | $suyNghi => ${moTa.joinToString("; ")}"
                lichSu.add(dong)
                NhatKy.ghi(this, dong)
                hienTrangThai("B$buoc: $suyNghi")

                val ghi = kq.optString("ghi_so_tay", "").trim()
                if (ghi.isNotEmpty()) soTay.them(ghi)

                Thread.sleep((cd.choGiay * 1000).toLong().coerceIn(0, 30_000))
            }
            NhatKy.ghi(this, "=== Đã dừng")
            dangChay = false
            hienTrangThai("đã dừng")
        } catch (e: Exception) {
            NhatKy.ghi(this, "LỖI: ${e.message}")
            dangChay = false
            hienTrangThai("Lỗi: ${e.message}")
        }
    }

    // ------------------------------------------------------------ chụp màn hình
    private fun chupManHinh(): Bitmap? {
        // Ẩn nút nổi để không lọt vào ảnh
        main.post { nut?.visibility = View.INVISIBLE }
        Thread.sleep(150)
        val xong = CountDownLatch(1)
        var ketQua: Bitmap? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        ketQua = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                        r.hardwareBuffer.close()
                    } catch (_: Exception) {
                    }
                    xong.countDown()
                }

                override fun onFailure(errorCode: Int) {
                    xong.countDown()
                }
            })
            xong.await(6, TimeUnit.SECONDS)
        } finally {
            main.post { nut?.visibility = View.VISIBLE }
        }
        return ketQua
    }

    // ------------------------------------------------------------ thao tác
    private fun cuChi(path: Path, ms: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms.coerceIn(1, 10_000)))
            .build()
        val xong = CountDownLatch(1)
        var ok = false
        main.post {
            val gui = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok = true; xong.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    xong.countDown()
                }
            }, null)
            if (!gui) xong.countDown()
        }
        xong.await(ms + 3000, TimeUnit.MILLISECONDS)
        return ok
    }

    private fun thucHien(t: JSONObject, tiLe: Double, rong: Int, cao: Int): String {
        fun qx(k: String) = (t.optDouble(k, 0.0) / tiLe).coerceIn(0.0, (rong - 1).toDouble()).toFloat()
        fun qy(k: String) = (t.optDouble(k, 0.0) / tiLe).coerceIn(0.0, (cao - 1).toDouble()).toFloat()
        val msGoc = t.optDouble("ms", 0.0)
        val ms = (if (msGoc.isNaN()) 0.0 else msGoc).coerceIn(0.0, 8000.0).toLong()

        return when (t.optString("loai")) {
            "cham" -> {
                val x = qx("x"); val y = qy("y")
                val ok = cuChi(Path().apply { moveTo(x, y) }, 60)
                "chạm (${x.toInt()},${y.toInt()})" + if (ok) "" else " [không được]"
            }
            "giu_vuot" -> {
                val x = qx("x"); val y = qy("y"); val x2 = qx("x2"); val y2 = qy("y2")
                val d = if (ms > 0) ms else 1000
                cuChi(Path().apply { moveTo(x, y); lineTo(x2, y2) }, d)
                "vuốt (${x.toInt()},${y.toInt()})->(${x2.toInt()},${y2.toInt()}) ${d}ms"
            }
            "giu" -> {
                val x = qx("x"); val y = qy("y")
                val d = if (ms > 0) ms else 800
                cuChi(Path().apply { moveTo(x, y) }, d)
                "giữ (${x.toInt()},${y.toInt()}) ${d}ms"
            }
            "quay_lai" -> {
                performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                "quay lại"
            }
            "cho" -> {
                val d = if (ms > 0) ms else 2000
                Thread.sleep(d)
                "chờ ${d}ms"
            }
            else -> "bỏ qua thao tác lạ"
        }
    }
}
