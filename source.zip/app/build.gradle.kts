plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.anbinh.aichoigame"
    compileSdk = 34

    defaultConfig {
        applicationId = "vn.anbinh.aichoigame"
        minSdk = 30          // Android 11+: cần để Trợ năng chụp được màn hình
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
